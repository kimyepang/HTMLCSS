$(function(){

  $(".con li").hide();
  $(".con li").eq(0).show();
  $(".list li").eq(0).find("p").addClass("on");
  $(".list li").eq(0).find("span").addClass("on");
  $(".list li").eq(0).addClass("on");
  $(".list li").find("div").eq(0).addClass("on");

$(".list li").click(function(){
  let i = $(this).index();
  console.log(i);
  $(".con li").hide();
  $(".con li").eq(i).show();
  $(".list li").removeClass("on");
  $(".list li p").removeClass("on");
  $(".list li span").removeClass("on");
  $(".list li>div").removeClass("on");
  $(this).find("p").addClass("on");
  $(this).find("span").addClass("on");
  $(this).addClass("on");
  $(this).find("div").addClass("on");
})

})